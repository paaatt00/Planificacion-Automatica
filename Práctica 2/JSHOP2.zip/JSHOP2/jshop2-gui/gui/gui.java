import JSHOP2.*;
import java.util.*;

public class gui{
	public static void main(String[] args) {
		problem.getPlans();
		new JSHOP2GUI();
	} 
}
